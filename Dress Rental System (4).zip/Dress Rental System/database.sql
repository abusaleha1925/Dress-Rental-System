

INSERT INTO mdresses (dress_name, dress_price, dress_img, Stock) 
VALUES 
('Royal Indian Groom Dress', 2500, 'Men/men29.jpg', 10),
('Long Sleeve Pullover', 399, 'Men/men25.jpg', 4),
('Embroidered Art Silk Sherwani', 2000,'Men/men28.jpg', 8),
('Beleza Indian Groom Dress', 1599,' Men/men27.jpg', 12),
('Men Style', 690, 'Men/men26.jpg', 6);


